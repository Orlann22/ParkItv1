import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, ActivityIndicator, Alert, BackHandler } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Link, router } from 'expo-router';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Home = () => {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const checkSession = async () => {
      try {
        const response = await axios.get('http://192.168.82.231:3000/session', {
          withCredentials: true,
        });

        if (response.data.loggedIn) {
          setUser(response.data.user);
        } else {
          router.replace('/sign-in'); // Redirect to login if not logged in
        }
      } catch (error) {
        console.error('Error checking session:', error);
      } finally {
        setLoading(false);
      }
    };

    checkSession();
  }, []);

  //   useEffect(() => {
  //   // Handle the back button press
  //   const backAction = () => {
  //      // Navigate to the home screen
  //     return true; // Prevent the default behavior (exit app)
  //   };

  //   // Add back button listener
  //   BackHandler.addEventListener('hardwareBackPress', backAction);

  //   // Cleanup listener on unmount
  //   return () => {
  //     BackHandler.removeEventListener('hardwareBackPress', backAction);
  //   };
  // }, []);


  const handleLogout = async () => {
    try {
      await AsyncStorage.removeItem('userSession'); // Clear local session
      await axios.post('http://192.168.82.231:3000/logout', {}, { withCredentials: true }); // End session on the server
      router.dismissAll();
      Alert.alert('Success', 'You have been logged out');
      router.replace('/sign-in'); // Redirect to login page
    } catch (error) {
      console.error('Error during logout:', error);
      Alert.alert('Error', 'Unable to logout. Please try again.');
    }
  };

  if (loading) {
    return (
      <SafeAreaView>
        <ActivityIndicator size="large" color="#0000ff" />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="bg-primary flex-1">
      <View>
        <View>
          <Text className="text-white pl-5 pt-3 font-pbold text-xl">Welcome, {user?.email || 'Guest'}!</Text>
        </View>
        <TouchableOpacity
          onPress={() => router.push('parking')}
          className="bg-blue-500 p-5 rounded-md m-5"
        >
        <Text className="text-lg text-white text-center font-psemibold">Pick Parking Slot</Text>
        </TouchableOpacity> 
        <TouchableOpacity
          onPress={handleLogout}
          className="bg-red-500 p-5 rounded-md m-5"
        >
          <Text className="text-lg text-white text-center font-psemibold">Logout</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default Home;

import { View, Text } from 'react-native'
import React, { useState } from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'

const Reservation = () => {
  return (
    <SafeAreaView>
      <Text>Reservation</Text>
    </SafeAreaView>
  )
}

export default Reservation
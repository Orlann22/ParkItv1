import { View, Text, TouchableOpacity, BackHandler } from 'react-native';
import React, { useEffect } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Link } from "expo-router";

const Parking = () => {
  const goToHome = async () => {
    router.dismissAll();
    router.replace('home');
  };

  // useEffect(() => {
  //   // Handle the back button press
  //   const backAction = () => {
  //     router.replace('home'); // Navigate to the home screen
  //     return true; // Prevent the default behavior (exit app)
  //   };

  //   // Add back button listener
  //   BackHandler.addEventListener('hardwareBackPress', backAction);

  //   // Cleanup listener on unmount
  //   return () => {
  //     BackHandler.removeEventListener('hardwareBackPress', backAction);
  //   };
  // }, []);

  return (
    <SafeAreaView className="bg-primary h-full">
      <View>
        <Text className="text-white text-xl font-psemibold pl-5 pt-5">Parking Slots</Text>
        <View className="flex flex-row items-center justify-evenly">
          {/* Slot 1 */}
          {/* <Link href="reservation" className="bg-white h-[250px] w-[150px] mt-5 mb-5"> */}
            <TouchableOpacity
              activeOpacity={0.7}
              className="bg-white h-[250px] w-[150px] mt-5 mb-5"
              onPress={() => router.push('reservation')}
            />
          {/* </Link> */}

          {/* Slot 2 */}
          {/* <Link href="reservation" className="bg-white h-[250px] w-[150px] mt-5 mb-5"> */}
            <TouchableOpacity
              activeOpacity={0.7}
              className="bg-white h-[250px] w-[150px] mt-5 mb-5"
              onPress={() => router.push('reservation')}
            />
          {/* </Link> */}
        </View>
        {/* Payment Button */}
        <TouchableOpacity
          onPress={goToHome}
          className="bg-blue-500 py-3 mx-3 rounded-md items-center"
        >
          <Text className="text-white text-lg">Go Back to Home</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default Parking;
